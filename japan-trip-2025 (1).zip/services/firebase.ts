import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy } from 'firebase/firestore';
import { Expense } from '../types';

// NOTE: Add your Firebase config here.
// If config is missing, the app will gracefully fallback to LocalStorage (Mock Mode).
// Casting import.meta to any to avoid TypeScript errors if types are not configured
const env = (import.meta as any).env || {};

const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.VITE_FIREBASE_APP_ID
};

// Simple check if config is present
const isConfigured = !!firebaseConfig.apiKey;

let db: any = null;

if (isConfigured) {
  try {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app);
  } catch (e) {
    console.error("Firebase init error:", e);
  }
}

export const addExpense = async (expense: Omit<Expense, 'id'>) => {
  if (isConfigured && db) {
    try {
      await addDoc(collection(db, 'expenses'), expense);
    } catch (e) {
      console.error("Error adding doc:", e);
      throw e;
    }
  } else {
    // Mock Mode
    const local = JSON.parse(localStorage.getItem('mock_expenses') || '[]');
    const newExpense = { ...expense, id: Date.now().toString() };
    local.push(newExpense);
    localStorage.setItem('mock_expenses', JSON.stringify(local));
    // Trigger a custom event to update UI in mock mode
    window.dispatchEvent(new Event('mock_storage_update'));
  }
};

export const subscribeToExpenses = (callback: (expenses: Expense[]) => void) => {
  if (isConfigured && db) {
    const q = query(collection(db, 'expenses'), orderBy('timestamp', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const expenses = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Expense));
      callback(expenses);
    });
  } else {
    // Mock Mode
    const loadLocal = () => {
      const local = JSON.parse(localStorage.getItem('mock_expenses') || '[]');
      // Sort desc
      local.sort((a: Expense, b: Expense) => b.timestamp - a.timestamp);
      callback(local);
    };
    
    loadLocal();
    window.addEventListener('mock_storage_update', loadLocal);
    
    return () => {
      window.removeEventListener('mock_storage_update', loadLocal);
    };
  }
};