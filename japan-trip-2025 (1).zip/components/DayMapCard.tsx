import React from 'react';
import { Map, Navigation } from 'lucide-react';

interface Props {
  locationTitle: string;
  googleMapsUrl?: string;
}

export const DayMapCard: React.FC<Props> = ({ locationTitle, googleMapsUrl }) => {
  return (
    <div className="mb-8 border border-jp-border rounded-xl overflow-hidden bg-white shadow-sm">
      <div className="p-3 border-b border-jp-border/50 bg-stone-50 flex justify-between items-center">
        <div className="flex items-center gap-2 text-jp-black">
          <Map className="w-4 h-4" />
          <span className="text-sm font-bold tracking-wider">{locationTitle} 地圖</span>
        </div>
        <span className="text-[10px] bg-jp-border px-2 py-0.5 rounded text-jp-gray">當日重點</span>
      </div>
      
      {/* Visual Map Placeholder - mimicking the screenshot style */}
      <div className="relative h-48 bg-[#F3F4F6] overflow-hidden group">
        {/* Placeholder Pattern mimicking a map */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
           <div className="relative">
             <div className="w-12 h-12 bg-jp-red/20 rounded-full animate-ping absolute inset-0"></div>
             <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg border-2 border-white relative z-10">
               <span className="text-2xl">📍</span>
             </div>
           </div>
        </div>
        
        {/* Map Lines Decor */}
        <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0,50 Q100,20 200,80 T400,100" stroke="#94a3b8" strokeWidth="4" fill="none" />
          <path d="M50,0 Q80,100 120,200" stroke="#fbbf24" strokeWidth="6" fill="none" />
        </svg>
      </div>

      {/* Action Button */}
      <a 
        href={googleMapsUrl} 
        target="_blank" 
        rel="noreferrer"
        className="block w-full py-4 text-center bg-white hover:bg-stone-50 transition-colors text-jp-indigo font-bold text-sm tracking-widest flex items-center justify-center gap-2"
      >
        <Navigation className="w-4 h-4" />
        開啟 Google Maps 導航
      </a>
    </div>
  );
};