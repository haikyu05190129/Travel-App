import React from 'react';
import { HourlyWeather } from '../types';
import { Sun, Cloud, CloudRain, Snowflake, Moon, CloudSun, CloudLightning } from 'lucide-react';

interface Props {
  location: string;
  locationUrl?: string;
  hourly: HourlyWeather[];
}

export const WeatherWidget: React.FC<Props> = ({ location, locationUrl, hourly }) => {
  
  const renderIcon = (emoji: string) => {
    // Japanese Traditional Colors Palette
    // Sun: Yamabuki-iro (#F7C114)
    // Cloud: Gin-nezu (#A1A3A6)
    // Rain: Hana-asagi (#2A83A2)
    // Snow: Kamenozoki (#A2D7DD)
    // Moon: Fuji-nezu (#6E75A4)

    switch (emoji) {
      case '☀️': 
        return (
          <div className="relative">
            <Sun className="w-8 h-8 text-[#F7C114] fill-[#F7C114]/20" strokeWidth={1.5} />
          </div>
        );
      
      case '☁️': 
        return (
          <div className="relative">
            <Cloud className="w-8 h-8 text-[#A1A3A6] fill-[#A1A3A6]/20" strokeWidth={1.5} />
          </div>
        );

      case '⛅': 
        return (
          <div className="relative">
            <CloudSun className="w-8 h-8 text-[#E48E00] fill-[#A1A3A6]/10" strokeWidth={1.5} />
          </div>
        );
      
      case '❄️': 
        return (
          <div className="relative">
            <Snowflake className="w-8 h-8 text-[#A2D7DD] fill-[#A2D7DD]/30" strokeWidth={1.5} />
          </div>
        );
      
      case '🌙': 
        return (
          <div className="relative">
            <Moon className="w-8 h-8 text-[#6E75A4] fill-[#6E75A4]/20" strokeWidth={1.5} />
          </div>
        );
      
      case '🌧️': 
        return (
          <div className="relative">
             <CloudRain className="w-8 h-8 text-[#2A83A2] fill-[#2A83A2]/10" strokeWidth={1.5} />
          </div>
        );
        
      default: 
        return <Cloud className="w-8 h-8 text-[#A1A3A6]" strokeWidth={1.5} />;
    }
  };

  return (
    <div className="mb-4 pt-4 border-t border-jp-border animate-fade-in">
      <div className="flex justify-between items-baseline mb-6">
        <a 
          href={locationUrl}
          target="_blank"
          rel="noreferrer" 
          className="group flex items-center gap-2"
        >
          <h2 className="text-xl font-bold text-jp-black tracking-[0.1em] group-hover:underline decoration-jp-red underline-offset-4 decoration-2">
            {location}
          </h2>
          {locationUrl && <MapPin className="w-3 h-3 text-jp-gray opacity-50" />}
        </a>
        <span className="text-[10px] text-jp-gray tracking-widest border border-jp-gray px-2 py-0.5 rounded-full">
          天気予報
        </span>
      </div>
      
      <div className="flex justify-between items-center px-2">
        {hourly.map((h, i) => (
          <div key={i} className="flex flex-col items-center gap-3 group cursor-default">
            <span className="text-[10px] text-jp-gray font-serif tracking-widest group-hover:text-jp-black transition-colors">{h.time}</span>
            <div className="transform transition-transform duration-300 group-hover:-translate-y-1 drop-shadow-sm">
              {renderIcon(h.icon)}
            </div>
            <span className="text-sm font-bold text-jp-black font-serif">{h.temp}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// Helper icon
const MapPin = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/>
    <circle cx="12" cy="10" r="3"/>
  </svg>
);
