import React, { useState, useEffect } from 'react';
import { Check, Backpack, Ticket, Shirt, Plug, Sparkles, Pill, Umbrella } from 'lucide-react';

// Default checklist data tailored for Japan Winter Trip
const DEFAULT_ITEMS = {
  "必備證件 & 錢包": {
    icon: <Ticket className="w-5 h-5" />,
    items: [
      "護照 (有效期6個月以上)",
      "Visit Japan Web QR Code 截圖",
      "機票憑證 / 登機證",
      "日幣現金 (建議分裝)",
      "信用卡 (JCB/Visa 建議備兩張)",
      "交通卡 (Suica/Pasmo) 或手機綁定",
      "海外旅遊保險單"
    ]
  },
  "衣物 (12月東京/富士山)": {
    icon: <Shirt className="w-5 h-5" />,
    items: [
      "保暖大衣 / 羽絨外套",
      "發熱衣 (Heattech) x 3-4",
      "毛衣 / 衛衣",
      "好走的鞋子 (防水佳)",
      "圍巾 / 毛帽 / 手套 (富士山區冷)",
      "換洗衣物 / 貼身衣物",
      "睡衣 (若飯店無提供喜歡的)",
      "免洗褲 (旅行方便)"
    ]
  },
  "3C 電子產品": {
    icon: <Plug className="w-5 h-5" />,
    items: [
      "手機 & 充電線",
      "行動電源 (需隨身攜帶)",
      "網卡 / SIM卡 / 漫遊開通",
      "轉接頭 (日本兩孔扁插，台灣通用)",
      "耳機",
      "相機 / 記憶卡 / 電池"
    ]
  },
  "盥洗 & 保養": {
    icon: <Sparkles className="w-5 h-5" />,
    items: [
      "牙刷 / 牙膏 (部分環保飯店不提供)",
      "卸妝 / 洗面乳",
      "保濕乳液 / 護唇膏 (日本乾燥)",
      "化妝品 / 防曬",
      "個人生理用品",
      "隱形眼鏡 / 藥水 / 眼鏡"
    ]
  },
  "常備藥品": {
    icon: <Pill className="w-5 h-5" />,
    items: [
      "感冒藥 / 止痛藥",
      "腸胃藥 / 暈車藥",
      "OK繃 / 外傷藥膏",
      "個人慢性病處方籤"
    ]
  },
  "隨身雜物": {
    icon: <Umbrella className="w-5 h-5" />,
    items: [
      "折疊傘 (必備)",
      "塑膠袋 (裝髒衣/垃圾)",
      "原子筆 (填寫文件用)",
      "衛生紙 / 濕紙巾",
      "暖暖包"
    ]
  }
};

export const PackingList: React.FC = () => {
  // State to track checked items: { "Category-ItemName": true/false }
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  // Load from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('japan_trip_packing_list');
    if (saved) {
      try {
        setCheckedItems(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse packing list", e);
      }
    }
  }, []);

  // Save to local storage whenever changed
  useEffect(() => {
    localStorage.setItem('japan_trip_packing_list', JSON.stringify(checkedItems));
  }, [checkedItems]);

  const toggleItem = (category: string, item: string) => {
    const key = `${category}-${item}`;
    setCheckedItems(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Calculate Progress
  const totalItems = Object.values(DEFAULT_ITEMS).reduce((acc, cat) => acc + cat.items.length, 0);
  const completedItems = Object.values(checkedItems).filter(Boolean).length;
  const progress = Math.round((completedItems / totalItems) * 100) || 0;

  return (
    <div className="pb-32 animate-fade-in">
      {/* Header Card - Styled EXACTLY like Visit Japan Web Card */}
      {/* Theme: Kachi-iro (Winning Indigo) for Success/Travel */}
      <div className="sticky top-24 z-10 mb-8 w-full block">
        <div className="block w-full relative rounded-xl overflow-hidden bg-gradient-to-br from-[#2B3A55] to-[#1A2333] text-white shadow-lg border border-white/5">
          
          {/* Red Accent Bar (Akane) */}
          <div className="absolute left-0 top-0 bottom-0 w-2.5 bg-[#B93E39]" />

          {/* Decorative Glow */}
          <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-[#B93E39]/10 blur-3xl rounded-full pointer-events-none"></div>

          <div className="p-6 pl-8 relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div>
                {/* Badge */}
                <span className="inline-block bg-[#B93E39] text-white text-[9px] font-bold tracking-[0.2em] px-2 py-0.5 rounded-sm mb-2 shadow-sm">
                  CHECKLIST
                </span>
                <h2 className="text-xl font-bold tracking-widest leading-tight">行李清單</h2>
              </div>
              
              {/* Icon */}
              <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center bg-white/5 shadow-inner">
                <Backpack className="w-5 h-5 text-stone-200" strokeWidth={1.5} />
              </div>
            </div>

            {/* Progress Section integrated into the card */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs tracking-wider opacity-90">
                <span className="font-serif italic text-stone-300">Completed</span>
                <span className="font-bold">{progress}%</span>
              </div>
              <div className="w-full h-1.5 bg-[#1A2333]/50 rounded-full overflow-hidden border border-white/10 backdrop-blur-sm">
                <div 
                  className="h-full bg-gradient-to-r from-stone-200 to-white shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-all duration-500 ease-out" 
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* List Content */}
      <div className="space-y-6">
        {Object.entries(DEFAULT_ITEMS).map(([category, data]) => (
          <div key={category} className="bg-white rounded-xl border border-jp-border overflow-hidden shadow-sm">
            {/* Category Header */}
            <div className="bg-stone-50 px-5 py-3 border-b border-jp-border flex items-center gap-2">
              <span className="text-jp-indigo">{data.icon}</span>
              <h3 className="font-bold text-jp-black tracking-wide text-sm">{category}</h3>
            </div>

            {/* Items */}
            <div className="divide-y divide-jp-border/50">
              {data.items.map(item => {
                const isChecked = !!checkedItems[`${category}-${item}`];
                return (
                  <div 
                    key={item} 
                    onClick={() => toggleItem(category, item)}
                    className={`flex items-start gap-4 px-5 py-4 cursor-pointer transition-colors active:bg-stone-50 group
                      ${isChecked ? 'bg-stone-50/50' : 'bg-white'}
                    `}
                  >
                    {/* Checkbox Design */}
                    <div className={`
                      w-5 h-5 rounded border flex-shrink-0 flex items-center justify-center mt-0.5 transition-all
                      ${isChecked 
                        ? 'bg-jp-indigo border-jp-indigo' 
                        : 'border-gray-300 group-hover:border-jp-gray bg-white'}
                    `}>
                      {isChecked && <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />}
                    </div>

                    {/* Text */}
                    <span className={`
                      text-sm leading-relaxed transition-all select-none
                      ${isChecked ? 'text-gray-400 line-through decoration-gray-300' : 'text-jp-black'}
                    `}>
                      {item}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        <div className="text-center py-8">
          <button 
            onClick={() => {
              if (window.confirm('確定要重置所有勾選狀態嗎？')) {
                setCheckedItems({});
              }
            }}
            className="text-xs text-jp-gray underline underline-offset-4 opacity-50 hover:opacity-100 transition-opacity"
          >
            重置清單
          </button>
        </div>
      </div>
    </div>
  );
};