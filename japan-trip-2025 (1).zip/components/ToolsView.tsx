import React from 'react';
import { FLIGHTS, HOTELS } from '../data';
import { VisitJapanWebCard } from './VisitJapanWebCard';
import { Phone, MapPin, FileText, Shield, Car, QrCode, Plane, BedDouble } from 'lucide-react';

export const ToolsView: React.FC = () => {
  return (
    <div className="space-y-12 pb-24">
      
      {/* Visit Japan Web Banner */}
      <section>
        <VisitJapanWebCard />
      </section>

      {/* Emergency Section */}
      <section>
        <div className="flex items-center gap-2 mb-4 border-b border-jp-red/20 pb-2">
           <Shield className="w-5 h-5 text-jp-red" />
           <h2 className="text-lg font-bold text-jp-red tracking-widest">
            緊急聯絡 & 支援
          </h2>
        </div>
        
        <div className="bg-white border border-jp-border shadow-sm">
          {/* Top Row: 110 & 119 */}
          <div className="flex border-b border-jp-border">
            <a href="tel:110" className="flex-1 p-6 flex flex-col items-center justify-center border-r border-jp-border active:bg-jp-red/5">
              <span className="text-[10px] text-jp-red font-bold tracking-widest mb-1">警察 (POLICE)</span>
              <span className="text-4xl font-serif font-bold text-jp-red">110</span>
            </a>
            <a href="tel:119" className="flex-1 p-6 flex flex-col items-center justify-center active:bg-jp-red/5">
              <span className="text-[10px] text-jp-red font-bold tracking-widest mb-1">救護/火警</span>
              <span className="text-4xl font-serif font-bold text-jp-red">119</span>
            </a>
          </div>

          {/* Japan Visitor Hotline */}
          <div className="p-6 flex items-center justify-between border-b border-jp-border relative overflow-hidden">
             <div className="relative z-10">
               <h3 className="font-bold text-lg leading-tight mb-1">訪日外國人<br/>醫療 & 急難熱線</h3>
               <p className="text-[10px] text-jp-gray uppercase tracking-wider mb-3">Japan Visitor Hotline (JNTO)</p>
               <div className="text-2xl font-bold font-serif text-jp-black tracking-wider">050-3816-2787</div>
               <p className="text-[10px] text-jp-gray mt-2 opacity-60">* 24小時對應 (英/中/韓)。生病受傷或發生事故時可撥打。</p>
             </div>
             <a href="tel:05038162787" className="w-12 h-12 bg-jp-black text-white rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-transform flex-shrink-0 z-10">
               <Phone className="w-5 h-5" />
             </a>
             {/* Decorative element */}
             <div className="absolute right-[-20px] bottom-[-20px] w-32 h-32 bg-stone-50 rounded-full z-0 opacity-50"></div>
          </div>

          {/* Representative Office */}
          <div className="bg-stone-50 p-5">
            <div className="flex items-center gap-2 mb-3">
              <span className="bg-jp-gray text-white text-[10px] px-1.5 py-0.5 rounded">外交部</span>
              <span className="text-sm font-bold text-jp-black">台北駐日經濟文化代表處</span>
            </div>
            <div className="space-y-1 pl-1">
               <div className="flex items-baseline justify-between text-sm">
                 <span className="text-jp-gray">上班時間</span>
                 <a href="tel:+81-3-3280-7811" className="font-mono text-jp-black">03-3280-7811</a>
               </div>
               <div className="flex items-baseline justify-between text-sm">
                 <span className="text-jp-red font-bold">急難救助</span>
                 <a href="tel:+81-80-1009-7179" className="font-mono text-jp-red font-bold">080-1009-7179</a>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Driver Card */}
      <section>
        <div className="flex items-center gap-2 mb-4 border-b border-jp-black pb-2">
           <Car className="w-5 h-5 text-jp-black" />
           <h2 className="text-lg font-bold text-jp-black tracking-widest">
            交通卡片
          </h2>
        </div>

        <div className="bg-white border-l-4 border-jp-black p-6 shadow-sm">
          <p className="text-[10px] text-jp-gray font-serif uppercase tracking-widest mb-4">給司機 (TO DRIVER)</p>
          <p className="text-2xl font-bold font-serif mb-2 leading-relaxed">
            ここへ行ってください。
          </p>
          <p className="text-xs text-jp-gray tracking-wider">
            (請載我到這裡)
          </p>
        </div>
      </section>

      {/* Flights & Hotels Condensed */}
      <section className="grid grid-cols-1 gap-12">
        {/* Flights */}
        <div>
           <div className="flex items-center gap-2 mb-4 border-b border-jp-black pb-2">
             <Plane className="w-5 h-5 text-jp-black" />
             <h2 className="text-lg font-bold text-jp-black tracking-widest">
              航班資訊
            </h2>
           </div>
           
           <div className="space-y-3">
            {FLIGHTS.map((f, i) => (
              <div key={i} className="bg-white p-4 border border-jp-border rounded-lg shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-lg text-jp-black font-serif">{f.code}</span>
                  <span className="text-[10px] bg-stone-100 px-2 py-1 rounded border border-stone-200 tracking-wider">{f.terminal}</span>
                </div>
                <div className="text-xs text-jp-gray flex flex-col gap-1">
                  <div className="font-bold text-jp-black">{f.route}</div>
                  <div>{f.time}</div>
                </div>
              </div>
            ))}
           </div>
        </div>

        {/* Hotels */}
        <div>
           <div className="flex items-center gap-2 mb-4 border-b border-jp-black pb-2">
             <BedDouble className="w-5 h-5 text-jp-black" />
             <h2 className="text-lg font-bold text-jp-black tracking-widest">
              住宿憑證
            </h2>
           </div>

           <div className="space-y-4">
            {HOTELS.map((h, i) => (
              <div key={i} className="bg-white p-5 border border-jp-border rounded-lg shadow-sm">
                <h3 className="font-bold text-base mb-1 text-jp-black">{h.name}</h3>
                <div className="text-xs text-jp-gray mb-3">{h.address}</div>
                
                {h.bookingId && (
                  <div className="text-xs text-jp-indigo flex items-center gap-2 mt-2 p-3 bg-indigo-50/50 rounded border border-indigo-100/50 mb-3">
                    <FileText className="w-4 h-4" /> 
                    <span className="tracking-wider font-medium">預約代號: <span className="font-mono text-sm">{h.bookingId}</span></span>
                  </div>
                )}
                
                <div className="flex gap-3">
                  <a href={h.mapUrl} target="_blank" rel="noreferrer" className="flex-1 text-xs text-jp-black border border-jp-border py-2.5 flex items-center justify-center gap-2 rounded hover:bg-stone-50 transition-colors">
                     <MapPin className="w-3.5 h-3.5" /> 地圖
                  </a>
                  {h.attachments?.map((att, idx) => (
                     <a key={idx} href={att.url} target="_blank" rel="noreferrer" className="flex-1 text-xs text-white bg-jp-indigo border border-jp-indigo py-2.5 flex items-center justify-center gap-2 rounded hover:opacity-90 transition-opacity shadow-sm">
                       {att.type === 'pdf' ? <FileText className="w-3.5 h-3.5" /> : <QrCode className="w-3.5 h-3.5" />}
                       {att.title}
                     </a>
                  ))}
                </div>
              </div>
            ))}
           </div>
        </div>
      </section>

    </div>
  );
};