import React, { useState, useEffect } from 'react';
import { Expense } from '../types';
import { addExpense, subscribeToExpenses } from '../services/firebase';
import { Plus, Wallet, Coins } from 'lucide-react';

export const ExpenseTracker: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [amount, setAmount] = useState('');
  const [item, setItem] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [currency, setCurrency] = useState<'JPY'|'TWD'>('JPY');

  useEffect(() => {
    const unsubscribe = subscribeToExpenses((data) => {
      setExpenses(data);
    });
    return () => unsubscribe && unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !item) return;

    await addExpense({
      item,
      amount: parseFloat(amount),
      currency,
      category: 'General',
      timestamp: Date.now()
    });

    setAmount('');
    setItem('');
    setIsAdding(false);
  };

  const totalJPY = expenses.filter(e => e.currency === 'JPY').reduce((acc, curr) => acc + curr.amount, 0);
  const totalTWD = expenses.filter(e => e.currency === 'TWD').reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="pb-24 animate-fade-in">
      
      {/* Summary Card - Styled EXACTLY like Visit Japan Web Card */}
      {/* Theme: Chitose-midori (Deep Evergreen) for Wealth/Money */}
      <div className="block w-full relative rounded-xl overflow-hidden bg-gradient-to-br from-[#314a43] to-[#1e2e2a] text-white shadow-lg mb-8 border border-white/5">
        
        {/* Gold Accent Bar (Kogane) */}
        <div className="absolute left-0 top-0 bottom-0 w-2.5 bg-[#E6B422]" />

        {/* Decorative Glow */}
        <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-[#E6B422]/10 blur-3xl rounded-full pointer-events-none"></div>

        <div className="p-6 pl-8 flex items-center justify-between relative z-10">
          <div>
             {/* Badge */}
             <span className="inline-block bg-[#E6B422] text-[#1e2e2a] text-[9px] font-bold tracking-[0.2em] px-2 py-0.5 rounded-sm mb-3 shadow-sm">
              TOTAL SPENDING
             </span>

             {/* Main Amount */}
             <div className="flex flex-col gap-0.5">
               <div className="flex items-baseline gap-2">
                 <span className="text-3xl font-serif font-bold tracking-wide">¥ {totalJPY.toLocaleString()}</span>
               </div>
               <div className="text-sm text-[#E6B422]/80 font-light tracking-wide font-serif">
                 約 NT$ {totalTWD.toLocaleString()}
               </div>
             </div>
          </div>

          {/* Icon */}
          <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center ml-4 bg-white/5 shadow-inner">
             <Coins className="w-6 h-6 text-[#E6B422]" strokeWidth={1.5} />
          </div>
        </div>
      </div>

      {/* Add Button Area - Removed px-1 to align perfectly with the card above */}
      <div className="mb-6 flex justify-between items-center">
        <h3 className="text-lg font-bold tracking-widest text-jp-black">消費紀錄</h3>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="group flex items-center gap-2 border border-jp-black px-4 py-2 rounded-full text-xs hover:bg-jp-black hover:text-white transition-all active:scale-95"
        >
          {isAdding ? '取消' : (
            <>
               <Plus className="w-3 h-3 group-hover:rotate-90 transition-transform" /> 
               記一筆
            </>
          )}
        </button>
      </div>

      {/* Form */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="mb-8 animate-fade-in-down">
          <div className="bg-white p-6 border border-jp-border rounded-xl shadow-sm">
            <div className="space-y-6">
              <div className="space-y-1">
                <label className="text-[10px] text-jp-gray tracking-widest uppercase">項目</label>
                <input 
                  type="text" 
                  placeholder="例如: 壽司, 伴手禮..." 
                  className="w-full py-2 border-b border-jp-border focus:border-jp-black outline-none bg-transparent rounded-none transition-colors"
                  value={item}
                  onChange={e => setItem(e.target.value)}
                  required
                />
              </div>
              
              <div className="flex gap-4">
                 <div className="w-1/3 space-y-1">
                    <label className="text-[10px] text-jp-gray tracking-widest uppercase">幣別</label>
                    <div className="relative">
                      <select 
                        className="w-full py-2 bg-transparent border-b border-jp-border outline-none rounded-none appearance-none font-serif"
                        value={currency}
                        onChange={e => setCurrency(e.target.value as any)}
                      >
                        <option value="JPY">JPY ¥</option>
                        <option value="TWD">TWD $</option>
                      </select>
                      <span className="absolute right-0 top-2 text-xs text-jp-gray pointer-events-none">▼</span>
                    </div>
                 </div>
                
                 <div className="flex-1 space-y-1">
                    <label className="text-[10px] text-jp-gray tracking-widest uppercase">金額</label>
                    <input 
                      type="number" 
                      placeholder="0" 
                      className="w-full py-2 border-b border-jp-border focus:border-jp-black outline-none bg-transparent rounded-none transition-colors font-serif"
                      value={amount}
                      onChange={e => setAmount(e.target.value)}
                      required
                    />
                 </div>
              </div>

              <button type="submit" className="w-full bg-jp-black text-white py-3.5 rounded-lg text-sm tracking-[0.2em] hover:opacity-90 transition-opacity shadow-lg">
                確認儲存
              </button>
            </div>
          </div>
        </form>
      )}

      {/* List */}
      <div className="space-y-3">
        {expenses.length === 0 ? (
          <div className="text-center text-jp-gray py-12 text-sm bg-stone-50 rounded-xl border border-dashed border-jp-border">
            尚無消費紀錄
          </div>
        ) : (
          expenses.map(exp => (
            <div key={exp.id} className="flex justify-between items-center p-4 bg-white border border-jp-border rounded-lg shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-jp-gray">
                   <Wallet className="w-4 h-4" strokeWidth={1.5} />
                </div>
                <div>
                  <div className="text-base text-jp-black font-medium">{exp.item}</div>
                  <div className="text-[10px] text-jp-gray tracking-wider uppercase">{new Date(exp.timestamp).toLocaleDateString()}</div>
                </div>
              </div>
              <div className="text-base font-bold font-serif text-jp-black">
                {exp.currency === 'JPY' ? '¥' : '$'} {exp.amount.toLocaleString()}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};