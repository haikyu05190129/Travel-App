import React from 'react';
import { ItineraryItem, Category } from '../types';
import { MapPin, Navigation, FileText, QrCode, ExternalLink } from 'lucide-react';

interface Props {
  item: ItineraryItem;
}

export const EventCard: React.FC<Props> = ({ item }) => {
  const getCategoryLabel = () => {
    switch (item.category) {
      case Category.FLIGHT: return '飛行';
      case Category.TRANSPORT: return '交通';
      case Category.HOTEL: return '住宿';
      case Category.FOOD: return '餐飲';
      case Category.SHOPPING: return '購物';
      default: return '觀光';
    }
  };

  return (
    <div className="relative pl-6 pb-10 border-l border-jp-border last:border-0 last:pb-0 group">
      {/* Timeline Dot - Simple and small */}
      <div className="absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full bg-jp-black transition-colors" />

      {/* Header Info */}
      <div className="flex items-baseline gap-3 mb-2">
        <span className="text-sm font-bold text-jp-black tracking-widest">
          {item.time}
        </span>
        <span className="text-xs text-jp-gray border border-jp-border px-2 py-0.5 rounded-full">
          {getCategoryLabel()}
        </span>
      </div>

      {/* Main Card Content */}
      <div 
        className="bg-white rounded-lg p-5 border border-jp-border active:bg-stone-50 transition-colors duration-200"
      >
        <div 
          className="flex justify-between items-start mb-3 cursor-pointer"
          onClick={() => item.googleMapsUrl && window.open(item.googleMapsUrl, '_blank')}
        >
          <h3 className="text-lg font-bold text-jp-black leading-snug flex-1 pr-4">
            {item.title}
          </h3>
          {item.googleMapsUrl && (
            <Navigation className="w-4 h-4 text-jp-gray mt-1" />
          )}
        </div>

        {/* Location Text */}
        <div className="flex items-center text-jp-gray text-sm mb-4">
          <MapPin className="w-3.5 h-3.5 mr-1.5" />
          <span className="tracking-wide">{item.location}</span>
        </div>

        {/* Description */}
        {item.description && (
          <p className="text-jp-black text-sm leading-7 mb-4 opacity-80">
            {item.description}
          </p>
        )}

        {/* Attachments Section (QR Codes, PDFs) */}
        {item.attachments && item.attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {item.attachments.map((file, idx) => (
              <a 
                key={idx}
                href={file.url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-3 py-2 bg-stone-100 rounded border border-stone-200 text-xs text-jp-black hover:bg-stone-200 transition-colors"
              >
                {file.type === 'pdf' && <FileText className="w-3.5 h-3.5 text-jp-red" />}
                {file.type === 'image' && <QrCode className="w-3.5 h-3.5 text-jp-indigo" />}
                {file.type === 'link' && <ExternalLink className="w-3.5 h-3.5 text-jp-gray" />}
                <span className="font-medium tracking-wide">{file.title}</span>
              </a>
            ))}
          </div>
        )}

        {/* Highlights / Badges */}
        {item.highlights && item.highlights.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {item.highlights.map((h, idx) => (
              <span 
                key={idx} 
                className={`text-xs px-2 py-1 border ${
                  h.type === 'critical' ? 'border-jp-red text-jp-red' : 
                  h.type === 'food' ? 'border-orange-400 text-orange-600' :
                  'border-jp-gray text-jp-gray'
                }`}
              >
                {h.text}
              </span>
            ))}
          </div>
        )}
        
        {/* Price Tag */}
        {item.price && (
          <div className="mt-4 pt-3 border-t border-dotted border-jp-border text-right">
             <span className="text-sm font-medium text-jp-black">{item.price}</span>
          </div>
        )}
      </div>
    </div>
  );
};