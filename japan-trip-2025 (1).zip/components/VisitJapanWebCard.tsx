import React from 'react';
import { ExternalLink } from 'lucide-react';

export const VisitJapanWebCard: React.FC = () => {
  return (
    <a 
      href="https://vjw-lp.digital.go.jp/zh-hant/" 
      target="_blank" 
      rel="noreferrer"
      className="block relative rounded-xl overflow-hidden bg-gradient-to-br from-[#222] to-[#111] text-white shadow-lg group mb-8 border border-white/5"
    >
      {/* Pink Accent Bar */}
      <div className="absolute left-0 top-0 bottom-0 w-2.5 bg-jp-red" />

      <div className="p-6 pl-8 flex items-center justify-between relative z-10">
        <div className="flex-1">
          {/* Badge */}
          <span className="inline-block bg-jp-red text-white text-[9px] font-bold tracking-[0.2em] px-2 py-0.5 rounded-sm mb-3 shadow-sm">
            MUST HAVE
          </span>
          
          {/* Title */}
          <h3 className="text-2xl font-serif font-bold tracking-wide mb-1 leading-tight group-hover:text-stone-200 transition-colors">
            Visit Japan Web
          </h3>
          
          {/* Subtitle */}
          <p className="text-[11px] text-gray-400 tracking-wider font-light">
            入境審查 & 海關申報 (請截圖 QR Code)
          </p>
        </div>
        
        {/* Icon Button */}
        <div className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center ml-4 group-hover:bg-white/10 group-active:scale-95 transition-all">
           <ExternalLink className="w-5 h-5 text-white" />
        </div>
      </div>
      
      {/* Subtle decorative glow */}
      <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-jp-red/10 blur-3xl rounded-full pointer-events-none"></div>
    </a>
  );
};